# URL Shortener
Simple web app made in React in order to shorten URLs using the Bitly API and copy them to the clipboard

## Technologies Used

- React
- Axios
- Bitly API
- HTML and CSS

![image](https://github.com/danish233/URL-Shortener/assets/95320101/4da179df-0cf7-43e3-ad0d-9537e7d2fdb0)
